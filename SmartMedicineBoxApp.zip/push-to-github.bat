@echo off
chcp 65001 >nul
echo ========================================
echo    智能药箱APP GitHub推送工具
echo ========================================
echo.

REM 设置项目目录
cd /d "%~dp0"

echo 项目路径: %cd%
echo.

REM 检查git
where git >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo ❌ 错误: 未找到git命令，请安装Git
    pause
    exit /b 1
)

echo 当前Git状态:
git log --oneline -3 2>nul
echo.

REM 检查远程仓库
git remote get-url origin >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo 配置远程仓库...
    git remote add origin https://github.com/xianyuyijinban/SmartMedicineBoxApp.git
)

echo 远程仓库: 
git remote get-url origin
echo.

echo ========================================
echo 准备推送到GitHub...
echo ========================================
echo.
echo 推送时会要求输入:
echo   用户名: xianyuyijinban
echo   密码: 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
echo.
pause

REM 推送代码
git branch -M main
git push -u origin main

if %ERRORLEVEL% equ 0 (
    echo.
    echo ========================================
    echo ✅ 推送成功!
    echo 仓库地址: https://github.com/xianyuyijinban/SmartMedicineBoxApp
    echo ========================================
) else (
    echo.
    echo ========================================
    echo ❌ 推送失败
    echo 请检查网络连接或GitHub Token权限
    echo ========================================
)

pause
