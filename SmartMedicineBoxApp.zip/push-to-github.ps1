# 智能药箱APP - GitHub推送脚本
# 使用方法: 右键选择"使用 PowerShell 运行"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   智能药箱APP GitHub推送工具" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 设置目录
$projectPath = $PSScriptRoot
Set-Location $projectPath

Write-Host "项目路径: $projectPath" -ForegroundColor Gray
Write-Host ""

# 检查git
if (!(Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "❌ 错误: 未找到git命令，请安装Git" -ForegroundColor Red
    exit 1
}

# 显示当前状态
Write-Host "当前Git状态:" -ForegroundColor Yellow
$commits = git log --oneline -3 2>$null
$commits | ForEach-Object { Write-Host "  $_" }
Write-Host ""

# 检查远程仓库
$remote = git remote get-url origin 2>$null
if ($LASTEXITCODE -ne 0 -or !$remote) {
    Write-Host "配置远程仓库..." -ForegroundColor Yellow
    git remote add origin "https://github.com/xianyuyijinban/SmartMedicineBoxApp.git"
}

Write-Host "远程仓库: $(git remote get-url origin)" -ForegroundColor Gray
Write-Host ""

# 推送选项
Write-Host "请选择推送方式:" -ForegroundColor Yellow
Write-Host "  1. 使用浏览器登录 (推荐)" -ForegroundColor Green
Write-Host "  2. 使用Token直接推送" -ForegroundColor White
Write-Host "  3. 使用SSH方式" -ForegroundColor White
Write-Host ""

$choice = Read-Host "请输入选项 (1-3)"

switch ($choice) {
    "1" {
        # 方式1: 使用普通推送，触发浏览器登录
        Write-Host ""
        Write-Host "将打开浏览器进行GitHub授权..." -ForegroundColor Cyan
        Write-Host "推送后会提示输入用户名和密码" -ForegroundColor Yellow
        Write-Host "  用户名: xianyuyijinban" -ForegroundColor White
        Write-Host "  密码: 使用GitHub Token作为密码" -ForegroundColor White
        Write-Host ""
        Read-Host "按Enter开始推送..."
        
        git branch -M main
        git push -u origin main
    }
    "2" {
        # 方式2: 使用token
        Write-Host ""
        $token = Read-Host "请输入GitHub Token" -AsSecureString
        $plainToken = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($token))
        
        git remote set-url origin "https://xianyuyijinban:$plainToken@github.com/xianyuyijinban/SmartMedicineBoxApp.git"
        git branch -M main
        git push -u origin main
        
        # 重置URL
        git remote set-url origin "https://github.com/xianyuyijinban/SmartMedicineBoxApp.git"
    }
    "3" {
        Write-Host ""
        Write-Host "SSH方式配置步骤:" -ForegroundColor Yellow
        Write-Host "1. 生成SSH密钥: ssh-keygen -t ed25519 -C 'your@email.com'" -ForegroundColor White
        Write-Host "2. 添加公钥到GitHub: Settings -> SSH and GPG keys" -ForegroundColor White
        Write-Host "3. 修改远程URL: git remote set-url origin git@github.com:xianyuyijinban/SmartMedicineBoxApp.git" -ForegroundColor White
        Write-Host "4. 重新推送" -ForegroundColor White
    }
    default {
        Write-Host "无效的选项" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ 推送成功!" -ForegroundColor Green
    Write-Host "仓库地址: https://github.com/xianyuyijinban/SmartMedicineBoxApp" -ForegroundColor White
} else {
    Write-Host "❌ 推送失败，请检查错误信息" -ForegroundColor Red
}
Write-Host "========================================" -ForegroundColor Cyan

Read-Host "按Enter退出"
